import pool from "../db/pool.js";

function SERVER_CONSOLE_LOGGER(data) {
  console.log(data);
}

export async function getProject(req, res) {
  const { projectId } = req.params;
  // teacher can see only own class; student can see only enrolled
  const projectQ = await pool.query("SELECT * FROM projects WHERE id=$1", [
    projectId,
  ]);
  const project = projectQ.rows[0];
  if (!project)
    return res.status(404).json({ success: false, message: "Not found" });

  return res.json({ success: true, project });
}

export async function getProjectWithMembers(req, res) {
  // console.log("getProjectWithMembers");
  const { projectId } = req.params;

  try {
    const projectQ = await pool.query("SELECT * FROM projects WHERE id=$1", [
      projectId,
    ]);
    const project = projectQ.rows[0];

    if (!project) {
      return res.status(404).json({ success: false, message: "Not found" });
    }

    // Members: OWNER + TEACHER (+ STUDENTS)
    const membersQ = await pool.query(
      `
      WITH c AS (
        SELECT id, teacher_id
        FROM classes
        WHERE id = $1
      ),
      members AS (
        -- owner
        SELECT $2::uuid AS user_id, 'OWNER'::text AS role
        UNION ALL
        -- teacher (may be null)
        SELECT teacher_id AS user_id, 'TEACHER'::text AS role
        FROM c
        UNION ALL
        -- students
        SELECT sc.student_id AS user_id, 'STUDENT'::text AS role
        FROM stud_classes sc
        WHERE sc.class_id = $1
      )
      SELECT DISTINCT ON (u.id)
        u.id,
        u.name,
        m.role
      FROM members m
      JOIN users u ON u.id = m.user_id
      WHERE m.user_id IS NOT NULL
      ORDER BY u.id, 
        CASE m.role 
          WHEN 'OWNER' THEN 1
          WHEN 'TEACHER' THEN 2
          WHEN 'STUDENT' THEN 3
          ELSE 99
        END
      `,
      [project.class_id, project.owner_id],
    );

    const members = membersQ.rows;

    return res.json({ success: true, project: { ...project, members } });
  } catch (err) {
    SERVER_CONSOLE_LOGGER(err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

export async function listClassProjects(req, res) {
  const { classId } = req.params;
  // teacher can see only own class; student can see only enrolled
  if (req.roles?.includes("teacher")) {
    const q = await pool.query(
      "SELECT 1 FROM classes WHERE id=$1 AND teacher_id=$2",
      [classId, req.user.id],
    );
    if (!q.rows[0])
      return res.status(403).json({ success: false, message: "Forbidden" });
  } else {
    const q = await pool.query(
      "SELECT 1 FROM stud_classes WHERE class_id=$1 AND student_id=$2",
      [classId, req.user.id],
    );
    if (!q.rows[0])
      return res.status(403).json({ success: false, message: "Forbidden" });
  }
  const { rows } = await pool.query(
    "SELECT * FROM projects WHERE class_id=$1 ORDER BY created_at DESC",
    [classId],
  );
  return res.json({ success: true, projects: rows });
}

export async function createProject(req, res) {
  const { classId } = req.params;
  const { name } = req.body || {};
  if (!name)
    return res.status(400).json({ success: false, message: "Missing name" });

  const c = await pool.query(
    "SELECT id FROM classes WHERE id=$1 AND teacher_id=$2",
    [classId, req.user.id],
  );
  if (!c.rows[0])
    return res.status(403).json({ success: false, message: "Forbidden" });

  const pr = await pool.query(
    "INSERT INTO projects (class_id, name, owner_id) VALUES ($1,$2,$3) RETURNING *",
    [classId, name, req.user.id],
  );

  // create branches for all enrolled students
  // await pool.query(
  //   `INSERT INTO branches (project_id, user_id)
  //    SELECT $1, sc.student_id FROM stud_classes sc WHERE sc.class_id=$2
  //    ON CONFLICT DO NOTHING`,
  //   [pr.rows[0].id, classId]
  // );

  return res.status(201).json({ success: true, project: pr.rows[0] });
}

export async function updateProject(req, res) {
  const { id } = req.params;
  const owner = await pool.query(
    `SELECT p.id FROM projects p
     JOIN classes c ON c.id=p.class_id
     WHERE p.id=$1 AND c.teacher_id=$2`,
    [id, req.user.id],
  );
  if (!owner.rows[0])
    return res.status(403).json({ success: false, message: "Forbidden" });

  const { name } = req.body || {};
  const { rows } = await pool.query(
    "UPDATE projects SET name=COALESCE($1,name) WHERE id=$2 RETURNING *",
    [name ?? null, id],
  );
  return res.json({ success: true, project: rows[0] });
}

export async function deleteProject(req, res) {
  const { id } = req.params;
  const owner = await pool.query(
    `SELECT p.id FROM projects p
     JOIN classes c ON c.id=p.class_id
     WHERE p.id=$1 AND c.teacher_id=$2`,
    [id, req.user.id],
  );
  if (!owner.rows[0])
    return res.status(403).json({ success: false, message: "Forbidden" });

  await pool.query("DELETE FROM projects WHERE id=$1", [id]); // cascades branches
  return res.json({ success: true });
}

function httpErr(res, code, message) {
  return res.status(code).json({ success: false, message });
}

async function getProjectAuth(projectId, userId) {
  // Owner proiect sau profesorul clasei, sau student înscris în clasa proiectului
  const q = await pool.query(
    `
    SELECT p.id, p.owner_id, p.class_id, c.teacher_id
    FROM projects p
    LEFT JOIN classes c ON c.id = p.class_id
    WHERE p.id = $1
    `,
    [projectId],
  );
  const pr = q.rows[0];
  if (!pr) return null;

  let canAccess = false;

  if (pr.owner_id === userId) canAccess = true;
  else if (pr.teacher_id && pr.teacher_id === userId) canAccess = true;
  else if (pr.class_id) {
    const sc = await pool.query(
      "SELECT 1 FROM stud_classes WHERE class_id=$1 AND student_id=$2 LIMIT 1",
      [pr.class_id, userId],
    );
    if (sc.rows[0]) canAccess = true;
  }
  return canAccess ? pr : { denied: true };
}

// GET /api/project/:projectId/nodes
export async function getNodes(req, res) {
  // console.log("getNodes");
  const { projectId } = req.params;

  const projectReq = await getProjectAuth(projectId, req.user.id);

  if (!projectReq) return httpErr(res, 404, "Not found");
  if (projectReq.denied) return httpErr(res, 403, "Forbidden");

  const { rows } = await pool.query(
    `
    SELECT
      n.id,
      n.project_id,
      n.label,

      cr.reviewer_id AS creator_id,

      EXISTS (
        SELECT 1
        FROM v1nodereviews del
        WHERE del.node_id = n.id
          AND del.reviewer_id = cr.reviewer_id
          AND del.verdict = 'DELETE'
      ) AS abandoned,

      CASE o.verdict
        WHEN 'ENDORSE'  THEN 'APPROVED'
        WHEN 'OPPOSE'   THEN 'REJECTED'
        WHEN 'CREATE'   THEN 'BASELINE'
        WHEN 'POSTPONE' THEN 'POSTPONED'
        ELSE NULL
      END AS owner_review,

      COALESCE(l.liked_by, ARRAY[]::uuid[])     AS liked_by,
      COALESCE(d.disliked_by, ARRAY[]::uuid[]) AS disliked_by

    FROM v1nodes n
    JOIN projects p
      ON p.id = n.project_id

    -- creator = review-ul CREATE
    JOIN v1nodereviews cr
      ON cr.node_id = n.id
     AND cr.verdict = 'CREATE'

    -- review-ul ownerului
    LEFT JOIN v1nodereviews o
      ON o.node_id = n.id
     AND o.reviewer_id = p.owner_id

    -- ENDORSE (exclus owner)
    LEFT JOIN LATERAL (
      SELECT ARRAY_AGG(DISTINCT r.reviewer_id) AS liked_by
      FROM v1nodereviews r
      WHERE r.node_id = n.id
        AND r.verdict = 'ENDORSE'
        AND r.reviewer_id <> p.owner_id
    ) l ON true

    -- OPPOSE (exclus owner)
    LEFT JOIN LATERAL (
      SELECT ARRAY_AGG(DISTINCT r.reviewer_id) AS disliked_by
      FROM v1nodereviews r
      WHERE r.node_id = n.id
        AND r.verdict = 'OPPOSE'
        AND r.reviewer_id <> p.owner_id
    ) d ON true

    WHERE n.project_id = $1
  `,
    // [projectId, req.user.id],
    [projectId],
  );
  // console.log("rows: " + JSON.stringify(rows));

  // output exact pe modelul cerut
  const nodes = rows.map((r) => ({
    id: r.id,
    label: r.label,

    creator_id: r.creator_id,
    abandoned: r.abandoned,

    owner_review: r.owner_review ?? null,

    liked_by: r.liked_by ?? [],
    disliked_by: r.disliked_by ?? [],
  }));

  return res.json({ success: true, nodes });
}

// GET /api/project/:projectId/nodes
// export async function getProjectNodes(req, res) {
//   const { projectId } = req.params;

//   const projectReq = await getProjectAuth(projectId, req.user.id);

//   if (!projectReq) return httpErr(res, 404, "Not found");
//   if (projectReq.denied) return httpErr(res, 403, "Forbidden");

//   // Join nodes -> users ca să primești numele creatorului în același răspuns
//   // Left join ca să nu pice dacă, din orice motiv, userul lipsește (defensiv)
//   const { rows } = await pool.query(
//     `
//   SELECT
//     n.id,
//     n.project_id,
//     n.label,
//     n.creator_id,
//     n.owner_decision,

//     u.name  AS creator_name,
//     u.email AS creator_email,

//     -- verdictul userului curent pe acest nod (sau NULL)
//     nr_my.verdict AS my_review_verdict,

//     -- counters (fara CREATED)
//     COALESCE(rv.positive_count, 0) AS positive_count,
//     COALESCE(rv.negative_count, 0) AS negative_count,
//     COALESCE(rv.review_total, 0)   AS review_total,

//     -- approval rate in procente (0..100)
//     COALESCE(rv.approval_rate_pct, 0) AS approval_rate_pct

//   FROM nodes n

//   LEFT JOIN users u
//     ON u.id = n.creator_id

//   LEFT JOIN node_reviews nr_my
//     ON nr_my.node_id = n.id
//    AND nr_my.reviewer_id = $2

//   LEFT JOIN (
//     SELECT
//       node_id,
//       COUNT(*) FILTER (WHERE verdict = 'POSITIVE') AS positive_count,
//       COUNT(*) FILTER (WHERE verdict = 'NEGATIVE') AS negative_count,
//       COUNT(*) FILTER (WHERE verdict IN ('POSITIVE','NEGATIVE')) AS review_total,
//       ROUND(
//         100.0 * COUNT(*) FILTER (WHERE verdict = 'POSITIVE')
//         / NULLIF(COUNT(*) FILTER (WHERE verdict IN ('POSITIVE','NEGATIVE')), 0)
//       , 2) AS approval_rate_pct
//     FROM node_reviews
//     WHERE verdict IN ('POSITIVE','NEGATIVE')  -- excludem CREATED din calcule
//     GROUP BY node_id
//   ) rv
//     ON rv.node_id = n.id

//   WHERE n.project_id = $1
//     AND n.deleted_at IS NULL

//   ORDER BY n.id ASC
//   `,
//     [projectId, req.user.id],
//   );

//   // Shape ergonomic pentru frontend: creator ca obiect
//   const nodes = rows.map((r) => ({
//     id: r.id,
//     projectId: r.project_id,
//     label: r.label,
//     ownerDecision: r.owner_decision,
//     creator: {
//       id: r.creator_id,
//       name: r.creator_name ?? null,
//       email: r.creator_email ?? null,
//     },
//     my_review_verdict: r.my_review_verdict ?? null,

//     reviews: {
//       positive: Number(r.positive_count ?? 0),
//       negative: Number(r.negative_count ?? 0),
//       total: Number(r.review_total ?? 0),
//       approvalRatePct: Number(r.approval_rate_pct ?? 0),
//     },
//   }));

//   return res.json({ success: true, nodes });
// }

// POST /api/project/:projectId/nodes
export async function createNode(req, res) {
  const { projectId } = req.params;
  const { label } = req.body || {};

  if (!label || typeof label !== "string")
    return httpErr(res, 400, "Missing label");

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  // let default_decision = "PENDING";
  // if (pr.owner_id === req.user.id) default_decision = "ACCEPTED";

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    const nodeIns = await c.query(
      `INSERT INTO v1nodes (project_id, label)
       VALUES ($1, $2)
       RETURNING id, project_id, label`,
      [projectId, label.trim()],
    );

    const node = nodeIns.rows[0];

    await c.query(
      `INSERT INTO v1nodereviews (node_id, reviewer_id, verdict)
       VALUES ($1, $2, $3)
       `,
      [node.id, req.user.id, "CREATE"],
    );

    await c.query("COMMIT");
    return res.status(201).json({ success: true, node });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, e?.message || "Server error");
  } finally {
    c.release();
  }
}

// POST /api/project/:projectId/nodes
export async function createProjectNode(req, res) {
  const { projectId } = req.params;
  const { label } = req.body || {};

  if (!label || typeof label !== "string")
    return httpErr(res, 400, "Missing label");

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  let default_decision = "PENDING";
  if (pr.owner_id === req.user.id) default_decision = "ACCEPTED";

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    const nodeIns = await c.query(
      `INSERT INTO nodes (project_id, label, creator_id, owner_decision)
       VALUES ($1, $2, $3, $4)
       RETURNING id, project_id, label, creator_id, owner_decision, deleted_at, deleted_by`,
      [projectId, label.trim(), req.user.id, default_decision],
    );

    const node = nodeIns.rows[0];

    // Auto-review CREATED (audit)
    await c.query(
      `INSERT INTO node_reviews (node_id, reviewer_id, verdict)
       VALUES ($1, $2, $3)
       ON CONFLICT (node_id, reviewer_id) DO NOTHING`,
      [node.id, req.user.id, "CREATED"],
    );

    await c.query("COMMIT");
    return res.status(201).json({ success: true, node });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, e?.message || "Server error");
  } finally {
    c.release();
  }
}

// DELETE /api/project/:projectId/nodes/:nodeId
export async function deleteProjectNode(req, res) {
  const { projectId, nodeId } = req.params;

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  const userId = req.user.id;
  const ownerId = pr.owner_id;
  const isOwner = userId === ownerId;

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    // 1) lock node row (prevents concurrent delete / concurrent checks)
    const nodeFound = await c.query(
      `SELECT id
         FROM v1nodes
        WHERE id = $1 AND project_id = $2
        FOR UPDATE`,
      [nodeId, projectId],
    );

    if (!nodeFound.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Node not found");
    }

    // 2) Gather facts from reviews, under lock-ish (same tx; node locked)
    //    - must be created by current user (CREATE exists)
    //    - must not be already abandoned by current user (DELETE exists)
    const myCreate = await c.query(
      `SELECT 1
         FROM v1nodereviews
        WHERE node_id = $1 AND reviewer_id = $2 AND verdict = 'CREATE'
        LIMIT 1`,
      [nodeId, userId],
    );

    if (!myCreate.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 403, "Cannot delete: node not created by you");
    }

    const myDelete = await c.query(
      `SELECT 1
         FROM v1nodereviews
        WHERE node_id = $1 AND reviewer_id = $2 AND verdict = 'DELETE'
        LIMIT 1`,
      [nodeId, userId],
    );

    if (myDelete.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(
        res,
        409,
        "Cannot delete: node already abandoned (soft-deleted) by you",
      );
    }

    if (!isOwner) {
      // GUEST RULES:

      // (a) Owner must NOT have any review on this node (no interaction from owner yet)
      //     If you want to allow owner's CREATE to count, change this query accordingly,
      //     but for guest nodes it should be "no rows at all".
      const ownerAnyReview = await c.query(
        `SELECT 1
           FROM v1nodereviews
          WHERE node_id = $1 AND reviewer_id = $2
          LIMIT 1`,
        [nodeId, ownerId],
      );

      if (ownerAnyReview.rows[0]) {
        await c.query("ROLLBACK");
        return httpErr(
          res,
          403,
          "Cannot delete: node already reviewed by owner",
        );
      }

      // (b) Decide hard vs soft:
      //     - if there are reviews from other guests => SOFT (insert DELETE review)
      //     - else => HARD (delete v1nodes row; cascades v1nodereviews)
      const otherGuestReviews = await c.query(
        `SELECT 1
           FROM v1nodereviews
          WHERE node_id = $1
            AND reviewer_id <> $2
            AND reviewer_id <> $3
          LIMIT 1`,
        [nodeId, userId, ownerId],
      );

      if (otherGuestReviews.rows[0]) {
        // SOFT DELETE: insert DELETE verdict for current user
        await c.query(
          `INSERT INTO v1nodereviews (node_id, reviewer_id, verdict)
           VALUES ($1, $2, 'DELETE')`,
          [nodeId, userId],
        );

        await c.query("COMMIT");
        return res.status(200).json({
          success: true,
          deletedId: nodeId,
          mode: "soft",
        });
      }

      // HARD DELETE: no other guest reviews exist
      const del = await c.query(
        `DELETE FROM v1nodes
          WHERE id = $1 AND project_id = $2
          RETURNING id`,
        [nodeId, projectId],
      );

      if (!del.rows[0]) {
        await c.query("ROLLBACK");
        return httpErr(res, 404, "Node not found");
      }

      await c.query("COMMIT");
      return res.status(200).json({
        success: true,
        deletedId: del.rows[0].id,
        mode: "hard",
      });
    }

    // OWNER RULES:
    // - Owner can delete only nodes created by him (already ensured by myCreate above)
    // - Always HARD delete (no propagation logic here)
    const del = await c.query(
      `DELETE FROM v1nodes
        WHERE id = $1 AND project_id = $2
        RETURNING id`,
      [nodeId, projectId],
    );

    if (!del.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Node not found");
    }

    await c.query("COMMIT");
    return res.status(200).json({
      success: true,
      deletedId: del.rows[0].id,
      mode: "hard",
    });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    console.error("deleteV1ProjectNode failed", {
      code: e.code,
      message: e.message,
      detail: e.detail,
      constraint: e.constraint,
      table: e.table,
    });
    return httpErr(res, 500, "Server error");
  } finally {
    c.release();
  }
}

// PATCH /api/project/:projectId/nodes/:nodeId/review
export async function upsertNodeReview(req, res) {
  const { projectId, nodeId } = req.params;
  // console.log(projectId, nodeId, req.body.verdict)

  // OWNER API:  'APPROVED' | 'REJECTED' | 'POSTPONED' | null
  // GUEST API:  'LIKED' | 'DISLIKED' | null
  const { verdict } = req.body || {};
  // console.log(verdict);

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  const ownerId = pr.owner_id;
  const actorId = req.user.id;
  const isOwner = actorId === ownerId;

  // const ownerVerdictByApi = {
  //   APPROVED: "ENDORSE",
  //   REJECTED: "OPPOSE",
  //   POSTPONED: "POSTPONE",
  // };

  // const guestVerdictByApi = {
  //   LIKED: "ENDORSE",
  //   DISLIKED: "OPPOSE",
  // };

  const isUndo = verdict == null;

  // mapare diferită în funcție de rol
  // const verdictDB = isUndo
  //   ? null
  //   : isOwner
  //     ? ownerVerdictByApi[verdict]
  //     : guestVerdictByApi[verdict];

  if (!isUndo && !verdict) {
    return httpErr(
      res,
      400,
      isOwner ? "InvalidOwnerVerdict" : "InvalidGuestVerdict",
    );
  }

  const c = await pool.connect();
  try {
    await c.query("BEGIN");


    // 1) node must belong to project
    const { rows: nrows } = await c.query(
      `SELECT 1 FROM v1nodes WHERE id = $1 AND project_id = $2`,
      [nodeId, projectId],
    );
    if (!nrows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Node not found");
    }

    // 2) derive creator (first CREATE)
    const { rows: creatorRows } = await c.query(
      `
      SELECT r.reviewer_id AS creator_id
      FROM v1nodereviews r
      WHERE r.node_id = $1 AND r.verdict = 'CREATE'::v1verdict
      ORDER BY r.id ASC
      LIMIT 1
      `,
      [nodeId],
    );
    const creatorId = creatorRows[0]?.creator_id || null;

    if (!creatorId) {
      await c.query("ROLLBACK");
      return httpErr(res, 409, "NodeMissingCreator");
    }

    // 3) abandoned = creator has DELETE
    const { rows: abRows } = await c.query(
      `
      SELECT EXISTS (
        SELECT 1
        FROM v1nodereviews d
        WHERE d.node_id = $1
          AND d.reviewer_id = $2
          AND d.verdict = 'DELETE'::v1verdict
      ) AS abandoned
      `,
      [nodeId, creatorId],
    );
    const abandoned = Boolean(abRows[0]?.abandoned);

    // 4) owner decision exists?
    const { rows: ownerDecRows } = await c.query(
      `
      SELECT EXISTS (
        SELECT 1
        FROM v1nodereviews r
        WHERE r.node_id = $1
          AND r.reviewer_id = $2
          AND r.verdict IN (
            'ENDORSE'::v1verdict,
            'OPPOSE'::v1verdict,
            'POSTPONE'::v1verdict
          )
      ) AS has_owner_decision
      `,
      [nodeId, ownerId],
    );
    const hasOwnerDecision = Boolean(ownerDecRows[0]?.has_owner_decision);

    // 5) rules
    if (isOwner) {
      // owner can decide only guest-created nodes (not own nodes)
      if (creatorId === ownerId) {
        await c.query("ROLLBACK");
        return httpErr(res, 403, "OwnerCannotDecideOwnNode");
      }
    } else {
      // guest can like/dislike:
      // - blocked if owner already decided
      // - cannot like/dislike own node unless abandoned
      if (hasOwnerDecision) {
        await c.query("ROLLBACK");
        return httpErr(res, 409, "OwnerDecisionAlreadySet");
      }

      const isOwnNode = creatorId === actorId;
      if (isOwnNode && !abandoned) {
        await c.query("ROLLBACK");
        return httpErr(res, 403, "GuestCannotReviewOwnActiveNode");
      }
    }

    // 6) undo = delete actor's "decision-like" rows (idempotent)
    if (isUndo) {
      const { rows } = await c.query(
        `
        DELETE FROM v1nodereviews
        WHERE node_id = $1
          AND reviewer_id = $2
          AND verdict IN (
            'ENDORSE'::v1verdict,
            'OPPOSE'::v1verdict,
            'POSTPONE'::v1verdict
          )
        RETURNING id, node_id, reviewer_id, verdict
        `,
        [nodeId, actorId],
      );

      await c.query("COMMIT");
      return res.status(200).json({
        success: true,
        role: isOwner ? "owner" : "guest",
        review: null,
        deleted: Boolean(rows[0]),
        node: { id: nodeId, creatorId, abandoned, hasOwnerDecision },
      });
    }

    // 7) set verdict (upsert) for actor
    // owner: can set ENDORSE/OPPOSE/POSTPONE
    // guest: can set ENDORSE/OPPOSE
    const { rows } = await c.query(
      `
      WITH upd AS (
        UPDATE v1nodereviews r
        SET verdict = $3::v1verdict
        WHERE r.node_id = $1
          AND r.reviewer_id = $2
          AND r.verdict IN (
            'ENDORSE'::v1verdict,
            'OPPOSE'::v1verdict,
            'POSTPONE'::v1verdict
          )
        RETURNING r.id, r.node_id, r.reviewer_id, r.verdict
      ),
      ins AS (
        INSERT INTO v1nodereviews (node_id, reviewer_id, verdict)
        SELECT $1, $2, $3::v1verdict
        WHERE NOT EXISTS (SELECT 1 FROM upd)
        RETURNING id, node_id, reviewer_id, verdict
      )
      SELECT * FROM upd
      UNION ALL
      SELECT * FROM ins;
      `,
      [nodeId, actorId, verdict],
    );

    await c.query("COMMIT");
    return res.status(200).json({
      success: true,
      role: isOwner ? "owner" : "guest",
      review: rows[0],
      node: { id: nodeId, creatorId, abandoned, hasOwnerDecision },
    });
  } catch (e) {
    console.error("setNodeOwnerDecision failed", e);
    await c.query("ROLLBACK").catch(() => {});
    return res.status(500).json({
      success: false,
      error: "Server error",
      detail: String(e?.message || e),
    });
  } finally {
    c.release();
  }
}

// PUT /api/project/:projectId/nodes/:nodeId/review
// Body: { verdict: 'POSITIVE' | 'NEGATIVE' | null }
// export async function upsertNodeReview(req, res) {
//   const { projectId, nodeId } = req.params;
//   const { verdict } = req.body || {};

//   const pr = await getProjectAuth(projectId, req.user.id);
//   if (!pr) return httpErr(res, 404, "Not found");
//   if (pr.denied) return httpErr(res, 403, "Forbidden");

//   // allow only POSITIVE/NEGATIVE/null
//   const v = verdict ?? null;
//   if (v !== null && v !== "POSITIVE" && v !== "NEGATIVE") {
//     return httpErr(res, 400, "Invalid verdict");
//   }

//   const c = await pool.connect();
//   try {
//     await c.query("BEGIN");

//     // ensure node belongs to project (and lock it for consistency)
//     const nodeQ = await c.query(
//       `SELECT id FROM nodes WHERE id=$1 AND project_id=$2 FOR UPDATE`,
//       [nodeId, projectId],
//     );
//     if (!nodeQ.rows[0]) {
//       await c.query("ROLLBACK");
//       return httpErr(res, 404, "Node not found");
//     }

//     if (v === null) {
//       await c.query(
//         `DELETE FROM node_reviews WHERE node_id=$1 AND reviewer_id=$2`,
//         [nodeId, req.user.id],
//       );
//       await c.query("COMMIT");
//       return res.json({ success: true, review: null });
//     }

//     const r = await c.query(
//       `INSERT INTO node_reviews (node_id, reviewer_id, verdict)
//        VALUES ($1, $2, $3)
//        ON CONFLICT (node_id, reviewer_id)
//        DO UPDATE SET verdict = EXCLUDED.verdict
//        RETURNING id, node_id, reviewer_id, verdict`,
//       [nodeId, req.user.id, v],
//     );

//     await c.query("COMMIT");
//     return res.json({ success: true, review: r.rows[0] });
//   } catch (e) {
//     await c.query("ROLLBACK").catch(() => {});
//     return httpErr(res, 500, e?.message || "Server error");
//   } finally {
//     c.release();
//   }
// }

// export async function add

// ==========================================================
// EDGES
// ==========================================================

// GET /api/project/:projectId/edges
export async function getProjectEdges(req, res) {
  const { projectId } = req.params;

  const projectReq = await getProjectAuth(projectId, req.user.id);
  if (!projectReq) return httpErr(res, 404, "Not found");
  if (projectReq.denied) return httpErr(res, 403, "Forbidden");

  try {
    const { rows } = await pool.query(
      `
      WITH e0 AS (
        SELECT e.id, e.source_id, e.target_id
        FROM v1edges e
        WHERE e.project_id = $1
      ),
      creator AS (
        SELECT
          r.edge_id,
          MIN(r.reviewer_id::text)::uuid AS creator_id
        FROM v1edgereviews r
        JOIN e0 ON e0.id = r.edge_id
        WHERE r.verdict = 'CREATE'::v1verdict
        GROUP BY r.edge_id
      ),
      abandoned AS (
        SELECT
          r.edge_id,
          TRUE AS abandoned
        FROM v1edgereviews r
        JOIN creator c ON c.edge_id = r.edge_id
        WHERE r.verdict = 'DELETE'::v1verdict
          AND r.reviewer_id = c.creator_id
        GROUP BY r.edge_id
      ),
      owner_review AS (
        SELECT
          r.edge_id,
          CASE
            WHEN bool_or(r.reviewer_id = $2 AND r.verdict = 'ENDORSE'::v1verdict) THEN 'APPROVED'
            WHEN bool_or(r.reviewer_id = $2 AND r.verdict = 'OPPOSE'::v1verdict)  THEN 'REJECTED'
            WHEN bool_or(r.reviewer_id = $2 AND r.verdict = 'POSTPONE'::v1verdict) THEN 'POSTPONED'
            ELSE NULL
          END AS owner_review
        FROM v1edgereviews r
        JOIN e0 ON e0.id = r.edge_id
        GROUP BY r.edge_id
      ),
      guest_agg AS (
        SELECT
          r.edge_id,
          ARRAY_REMOVE(
            ARRAY_AGG(DISTINCT r.reviewer_id) FILTER (
              WHERE r.verdict = 'ENDORSE'::v1verdict AND r.reviewer_id <> $2
            ),
            NULL
          ) AS liked_by,
          ARRAY_REMOVE(
            ARRAY_AGG(DISTINCT r.reviewer_id) FILTER (
              WHERE r.verdict = 'OPPOSE'::v1verdict AND r.reviewer_id <> $2
            ),
            NULL
          ) AS disliked_by
        FROM v1edgereviews r
        JOIN e0 ON e0.id = r.edge_id
        GROUP BY r.edge_id
      )
      SELECT
        e0.id,
        e0.source_id,
        e0.target_id,
        c.creator_id,
        COALESCE(ab.abandoned, FALSE) AS abandoned,
        o.owner_review,
        COALESCE(g.liked_by, ARRAY[]::uuid[])    AS liked_by,
        COALESCE(g.disliked_by, ARRAY[]::uuid[]) AS disliked_by
      FROM e0
      LEFT JOIN creator c      ON c.edge_id = e0.id
      LEFT JOIN abandoned ab   ON ab.edge_id = e0.id
      LEFT JOIN owner_review o ON o.edge_id = e0.id
      LEFT JOIN guest_agg g    ON g.edge_id = e0.id
      ORDER BY e0.id ASC
  `,
      [projectId, projectReq.owner_id],
    );

    const edges = rows.map((r) => {
      // const likedBy = Array.isArray(r.liked_by) ? r.liked_by : [];
      // const dislikedBy = Array.isArray(r.disliked_by) ? r.disliked_by : [];

      // const likesCount = likedBy.length;
      // const dislikesCount = dislikedBy.length;
      // const total = likesCount + dislikesCount;
      // const approvalRate = total > 0 ? likesCount / total : 0;

      return {
        id: r.id,
        source_id: r.source_id,
        target_id: r.target_id,

        creator_id: r.creator_id ?? null,
        abandoned: Boolean(r.abandoned),
        owner_review: r.owner_review ?? null, // APPROVED | REJECTED | POSTPONED | null

        liked_by:r.liked_by,
        disliked_by:r.disliked_by,
        // approvalRate,
        // likesCount,
        // dislikesCount,
      };
    });

    return res.json({ success: true, edges });
  } catch (e) {
    // ca să vezi exact cauza 500-ului în log
    console.error("getProjectEdges failed:", e);
    return httpErr(res, 500, e?.message || "Server error");
  }
}

// POST /api/project/:projectId/edges
// Body: { source_id: uuid, target_id: uuid }
export async function createProjectEdge(req, res) {
  const { projectId } = req.params;
  const { source_id, target_id } = req.body || {};
  console.log(source_id, target_id);

  if (!source_id || !target_id)
    return httpErr(res, 400, "Missing source_id/target_id");
  if (source_id === target_id)
    return httpErr(res, 400, "source_id and target_id must differ");

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  // let default_decision = "PENDING";
  // if (pr.owner_id === req.user.id) default_decision = "ACCEPTED";

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    // Ensure both nodes exist, belong to this project, and are not deleted.
    // IMPORTANT: use ANY($2::uuid[]) instead of IN ($2, $3)
    const nodesOk = await c.query(
      `
      SELECT COUNT(*)::int AS cnt
      FROM v1nodes
      WHERE project_id = $1
        AND id = ANY($2::uuid[])
      `,
      [projectId, [source_id, target_id]],
    );
    console.log(nodesOk);

    if ((nodesOk.rows[0]?.cnt ?? 0) !== 2) {
      await c.query("ROLLBACK");
      return httpErr(res, 409, "Invalid source/target for project");
    }

    const edgeIns = await c.query(
      `
      INSERT INTO v1edges (project_id, source_id, target_id)
      VALUES ($1, $2, $3)
      RETURNING id, project_id, source_id, target_id
      `,
      [projectId, source_id, target_id],
    );

    const edge = edgeIns.rows[0];

    // Auto-review CREATED (audit)
    await c.query(
      `
      INSERT INTO v1edgereviews (edge_id, reviewer_id, verdict)
      VALUES ($1, $2, $3)
      `,
      [edge.id, req.user.id, "CREATE"],
    );

    await c.query("COMMIT");
    return res.status(201).json({ success: true, edge });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, e?.message || "Server error");
  } finally {
    c.release();
  }
}

// DELETE /api/project/:projectId/edges/:edgeId
export async function deleteProjectEdge(req, res) {
  const { projectId, edgeId } = req.params;

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    const found = await c.query(
      `
      SELECT id, deleted_at
      FROM edges
      WHERE id = $1 AND project_id = $2
      FOR UPDATE
      `,
      [edgeId, projectId],
    );

    if (!found.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Edge not found");
    }

    const del = await c.query(
      `
      DELETE FROM edges
      WHERE id = $1 AND project_id = $2
      RETURNING id
      `,
      [edgeId, projectId],
    );

    if (!del.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Edge not found");
    }

    await c.query("COMMIT");
    return res.status(200).json({ success: true, deletedId: del.rows[0].id });
  } catch (e) {
    console.error("deleteProjectEdge failed", {
      code: e.code,
      message: e.message,
      detail: e.detail,
      constraint: e.constraint,
      table: e.table,
    });
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, "Server error");
  } finally {
    c.release();
  }
}

// PATCH /api/project/:projectId/edges/:edgeId/owner-decision
// Body: { decision: 'ACCEPTED' | 'REJECTED' }
export async function setEdgeOwnerDecision(req, res) {
  const { projectId, edgeId } = req.params;
  const { decision } = req.body || {};

  if (decision !== "ACCEPTED" && decision !== "REJECTED") {
    return httpErr(res, 400, "Invalid decision");
  }

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  if (pr.owner_id !== req.user.id) return httpErr(res, 403, "OwnerOnly");

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    const edge = await c.query(
      `
      SELECT id, owner_decision, deleted_at
      FROM edges
      WHERE id=$1 AND project_id=$2
      FOR UPDATE
      `,
      [edgeId, projectId],
    );

    if (!edge.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Edge not found");
    }

    if (edge.rows[0].deleted_at) {
      await c.query("ROLLBACK");
      return httpErr(res, 409, "EdgeDeleted");
    }

    if (edge.rows[0].owner_decision !== "PENDING") {
      await c.query("ROLLBACK");
      return httpErr(res, 409, `Already${edge.rows[0].owner_decision}`);
    }

    const upd = await c.query(
      `
      UPDATE edges
      SET owner_decision = $3
      WHERE id=$1 AND project_id=$2
      RETURNING id, project_id, source_id, target_id, creator_id, owner_decision, deleted_at, deleted_by
      `,
      [edgeId, projectId, decision],
    );

    await c.query("COMMIT");
    return res.status(200).json({ success: true, edge: upd.rows[0] });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, "Server error");
  } finally {
    c.release();
  }
}

// PUT /api/project/:projectId/edges/:edgeId/review
// Body: { verdict: 'POSITIVE' | 'NEGATIVE' | null }
export async function upsertEdgeReview(req, res) {
  const { projectId, edgeId } = req.params;
  const { verdict } = req.body || {};

  const pr = await getProjectAuth(projectId, req.user.id);
  if (!pr) return httpErr(res, 404, "Not found");
  if (pr.denied) return httpErr(res, 403, "Forbidden");

  const v = verdict ?? null;
  if (v !== null && v !== "POSITIVE" && v !== "NEGATIVE") {
    return httpErr(res, 400, "Invalid verdict");
  }

  const c = await pool.connect();
  try {
    await c.query("BEGIN");

    const edgeQ = await c.query(
      `SELECT id FROM edges WHERE id=$1 AND project_id=$2 FOR UPDATE`,
      [edgeId, projectId],
    );
    if (!edgeQ.rows[0]) {
      await c.query("ROLLBACK");
      return httpErr(res, 404, "Edge not found");
    }

    if (v === null) {
      await c.query(
        `DELETE FROM edge_reviews WHERE edge_id=$1 AND reviewer_id=$2`,
        [edgeId, req.user.id],
      );
      await c.query("COMMIT");
      return res.json({ success: true, review: null });
    }

    const r = await c.query(
      `
      INSERT INTO edge_reviews (edge_id, reviewer_id, verdict)
      VALUES ($1, $2, $3)
      ON CONFLICT (edge_id, reviewer_id)
      DO UPDATE SET verdict = EXCLUDED.verdict
      RETURNING id, edge_id, reviewer_id, verdict
      `,
      [edgeId, req.user.id, v],
    );

    await c.query("COMMIT");
    return res.json({ success: true, review: r.rows[0] });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {});
    return httpErr(res, 500, e?.message || "Server error");
  } finally {
    c.release();
  }
}
